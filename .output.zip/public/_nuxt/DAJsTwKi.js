const a=()=>({legacy:!1,fallbackLocale:"en-US"});export{a as default};
