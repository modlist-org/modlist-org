import mongoose from 'mongoose';

const { Schema, model, models } = mongoose;
const ModVersionSchema = new Schema({
  version: { type: String, required: true },
  downloadUrl: { type: String, required: true },
  changelog: { type: String, default: "" },
  isApproved: { type: Boolean, default: false, index: true },
  rejectionReason: { type: String, default: "" },
  submittedBy: { type: Schema.Types.ObjectId, ref: "User", required: true },
  createdAt: { type: Date, default: Date.now }
});
const PendingModEditSchema = new Schema({
  name: { type: String },
  summary: { type: String },
  description: { type: String },
  game: { type: String, enum: ["adofai", "rhythm-doctor"] },
  categories: [{ type: String, enum: ["ui", "gameplay", "utility", "visuals", "library"] }],
  logo: { type: String },
  sourceUrl: { type: String },
  createdAt: { type: Date, default: Date.now }
});
const ModSchema = new Schema({
  name: { type: String, required: true },
  slug: { type: String, required: true, unique: true, lowercase: true, index: true },
  summary: { type: String, required: true },
  description: { type: String, default: "" },
  game: { type: String, required: true, enum: ["adofai", "rhythm-doctor"], index: true },
  categories: [{ type: String, enum: ["ui", "gameplay", "utility", "visuals", "library"], index: true, default: ["ui"] }],
  authorId: { type: Schema.Types.ObjectId, ref: "User", required: true, index: true },
  collaboratorIds: [{ type: Schema.Types.ObjectId, ref: "User", index: true }],
  pendingCollaboratorIds: [{ type: Schema.Types.ObjectId, ref: "User", index: true, default: [] }],
  pendingEdit: { type: PendingModEditSchema, default: null },
  isApproved: { type: Boolean, default: false, index: true },
  rejectionReason: { type: String, default: "" },
  editRejectionReason: { type: String, default: "" },
  logo: { type: String, default: "" },
  sourceUrl: { type: String, default: "" },
  downloads: { type: Number, default: 0 },
  versions: [ModVersionSchema],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});
const Mod = models.Mod || model("Mod", ModSchema);

export { Mod as M };
//# sourceMappingURL=Mod.mjs.map
