import { n as defineEventHandler, l as createError, N as readBody, U as User, P as sendDiscordWebhook } from '../../_/nitro.mjs';
import mongoose from 'mongoose';
import { M as Mod } from '../../_/Mod.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'node:crypto';

const index_post = defineEventHandler(async (event) => {
  const currentUser = event.context.user;
  if (!currentUser) {
    throw createError({
      statusCode: 401,
      statusMessage: "You must be logged in to submit a mod."
    });
  }
  const body = await readBody(event);
  const {
    name,
    slug,
    game,
    categories,
    summary,
    description,
    version,
    downloadUrl,
    changelog,
    collaboratorIds,
    logo,
    sourceUrl
  } = body;
  if (!name || !slug || !game || !categories || !summary || !version || !downloadUrl) {
    throw createError({
      statusCode: 400,
      statusMessage: "Required fields: name, slug, game, categories, summary, version, and downloadUrl."
    });
  }
  if (logo && typeof logo === "string" && logo.length > 15e5) {
    throw createError({
      statusCode: 400,
      statusMessage: "Logo size must be smaller than 1MB."
    });
  }
  if (sourceUrl && typeof sourceUrl === "string") {
    if (!sourceUrl.startsWith("http://") && !sourceUrl.startsWith("https://")) {
      throw createError({
        statusCode: 400,
        statusMessage: "Source code link must be a valid HTTP/HTTPS URL."
      });
    }
  }
  if (!["adofai", "rhythm-doctor"].includes(game)) {
    throw createError({
      statusCode: 400,
      statusMessage: "Invalid game selected."
    });
  }
  if (!Array.isArray(categories) || categories.length === 0 || categories.some((cat) => !["ui", "gameplay", "utility", "visuals", "library"].includes(cat))) {
    throw createError({
      statusCode: 400,
      statusMessage: "Invalid or empty categories selected."
    });
  }
  const formattedSlug = slug.toLowerCase().replace(/[^a-z0-9-_]/g, "");
  if (formattedSlug.length === 0) {
    throw createError({
      statusCode: 400,
      statusMessage: "Invalid slug. Must contain only alphanumeric characters, dashes, and underscores."
    });
  }
  const existingMod = await Mod.findOne({ slug: formattedSlug });
  if (existingMod) {
    throw createError({
      statusCode: 400,
      statusMessage: "A mod with this slug already exists. Please choose a different slug."
    });
  }
  if (!downloadUrl.startsWith("http://") && !downloadUrl.startsWith("https://")) {
    throw createError({
      statusCode: 400,
      statusMessage: "Download link must be a valid direct HTTP/HTTPS URL (e.g. GitHub release)."
    });
  }
  const validatedCollabIds = [];
  if (Array.isArray(collaboratorIds) && collaboratorIds.length > 0) {
    for (const collabId of collaboratorIds) {
      if (collabId === currentUser.id) continue;
      const collabUser = await User.findById(collabId);
      if (collabUser) {
        validatedCollabIds.push(new mongoose.Types.ObjectId(collabUser._id));
      }
    }
  }
  const isAutoApproved = currentUser.isVerifiedDeveloper || currentUser.isAdmin;
  try {
    const mod = new Mod({
      name,
      slug: formattedSlug,
      game,
      categories,
      summary,
      description: description || "",
      authorId: new mongoose.Types.ObjectId(currentUser.id),
      collaboratorIds: [],
      pendingCollaboratorIds: validatedCollabIds,
      isApproved: isAutoApproved,
      logo: logo || "",
      sourceUrl: sourceUrl || "",
      downloads: 0,
      versions: [
        {
          version,
          downloadUrl,
          changelog: changelog || "Initial release",
          isApproved: isAutoApproved,
          submittedBy: new mongoose.Types.ObjectId(currentUser.id),
          createdAt: /* @__PURE__ */ new Date()
        }
      ],
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    });
    await mod.save();
    if (mod.isApproved) {
      const populatedMod = await Mod.findById(mod._id).populate("authorId");
      if (populatedMod) {
        sendDiscordWebhook(populatedMod).catch((err) => {
          console.error("Failed to send Discord webhook on creation:", err);
        });
      }
    }
    return {
      success: true,
      mod: {
        id: mod._id,
        slug: mod.slug,
        isApproved: mod.isApproved
      }
    };
  } catch (error) {
    console.error("Error creating mod:", error);
    const err = error;
    throw createError({
      statusCode: 500,
      statusMessage: `Failed to create mod: ${err.message || String(error)}`
    });
  }
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
