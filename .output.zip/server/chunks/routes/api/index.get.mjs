import { n as defineEventHandler, w as getQuery, l as createError } from '../../_/nitro.mjs';
import mongoose from 'mongoose';
import { M as Mod } from '../../_/Mod.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'node:crypto';

const index_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const game = query.game;
  const categories = query.categories;
  const search = query.search;
  const currentUser = event.context.user;
  const filter = {};
  if (game && game !== "all") {
    const games = game.split(",").filter(Boolean);
    const validGames = games.filter((g) => ["adofai", "rhythm-doctor"].includes(g));
    if (validGames.length > 0) {
      filter.game = { $in: validGames };
    }
  }
  if (categories && categories !== "all") {
    const cats = categories.split(",").filter(Boolean);
    const validCats = cats.filter((cat) => ["ui", "gameplay", "utility", "visuals", "library"].includes(cat));
    if (validCats.length > 0) {
      filter.categories = { $in: validCats };
    }
  }
  if (search && search.trim().length > 0) {
    const searchRegex = { $regex: search, $options: "i" };
    filter.$or = [
      { name: searchRegex },
      { summary: searchRegex },
      { slug: searchRegex }
    ];
  }
  const pending = query.pending === "true";
  if (pending) {
    if (!currentUser) {
      throw createError({
        statusCode: 401,
        statusMessage: "You must be logged in to view pending mods."
      });
    }
    filter.isApproved = false;
    const originalOr = filter.$or;
    const pendingScoping = [
      { authorId: new mongoose.Types.ObjectId(currentUser.id) },
      { collaboratorIds: new mongoose.Types.ObjectId(currentUser.id) }
    ];
    if (originalOr && originalOr.length > 0) {
      delete filter.$or;
      filter.$and = [
        { $or: originalOr },
        { $or: pendingScoping }
      ];
    } else {
      filter.$or = pendingScoping;
    }
  } else {
    filter.isApproved = true;
  }
  try {
    const mods = await Mod.find(filter).populate("authorId", "username globalName avatar isVerifiedDeveloper").populate("collaboratorIds", "username globalName avatar isVerifiedDeveloper").sort({ updatedAt: -1 });
    const sanitizedMods = mods.map((mod) => {
      var _a;
      const modObj = mod.toObject();
      let approvedVersions = modObj.versions || [];
      const isOwnerOrAdmin = currentUser && (currentUser.isAdmin || ((_a = modObj.authorId) == null ? void 0 : _a._id.toString()) === currentUser.id || (modObj.collaboratorIds || []).some((c) => c._id.toString() === currentUser.id));
      if (!isOwnerOrAdmin) {
        approvedVersions = approvedVersions.filter((v) => v.isApproved);
      }
      const latestVersion = approvedVersions.sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      )[0] || null;
      return {
        ...modObj,
        versions: approvedVersions,
        latestVersion
      };
    });
    return { mods: sanitizedMods };
  } catch (error) {
    console.error("Fetch mods error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Failed to retrieve mods"
    });
  }
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
