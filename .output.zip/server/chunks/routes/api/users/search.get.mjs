import { n as defineEventHandler, l as createError, w as getQuery, U as User } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'mongoose';
import 'node:url';
import 'node:crypto';

const search_get = defineEventHandler(async (event) => {
  if (!event.context.user) {
    throw createError({
      statusCode: 401,
      statusMessage: "Unauthorized"
    });
  }
  const query = getQuery(event);
  const q = query.q;
  if (!q || q.trim().length === 0) {
    return { users: [] };
  }
  try {
    const users = await User.find({
      $or: [
        { username: { $regex: q, $options: "i" } },
        { globalName: { $regex: q, $options: "i" } }
      ]
    }).limit(10).select("_id username globalName avatar");
    return { users };
  } catch (error) {
    console.error("User search error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Failed to search users"
    });
  }
});

export { search_get as default };
//# sourceMappingURL=search.get.mjs.map
