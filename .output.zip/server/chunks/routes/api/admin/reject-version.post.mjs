import { n as defineEventHandler, l as createError, N as readBody } from '../../../_/nitro.mjs';
import { M as Mod } from '../../../_/Mod.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'mongoose';
import 'node:url';
import 'node:crypto';

const rejectVersion_post = defineEventHandler(async (event) => {
  const currentUser = event.context.user;
  if (!currentUser || !currentUser.isAdmin) {
    throw createError({
      statusCode: 403,
      statusMessage: "Access denied. Administrator privileges required."
    });
  }
  const body = await readBody(event);
  const { modId, versionId, reason } = body;
  if (!modId || !versionId) {
    throw createError({
      statusCode: 400,
      statusMessage: "Required parameters: modId and versionId."
    });
  }
  const rejectionReason = reason || "No reason provided.";
  try {
    const mod = await Mod.findById(modId);
    if (!mod) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mod not found."
      });
    }
    const ver = mod.versions.find((v) => {
      var _a;
      return ((_a = v._id) == null ? void 0 : _a.toString()) === versionId;
    });
    if (!ver) {
      throw createError({
        statusCode: 404,
        statusMessage: "Version not found."
      });
    }
    ver.isApproved = false;
    ver.rejectionReason = rejectionReason;
    mod.updatedAt = /* @__PURE__ */ new Date();
    await mod.save();
    return {
      success: true,
      message: "Version rejected successfully."
    };
  } catch (error) {
    console.error("Reject version error:", error);
    const err = error;
    if (err.statusCode) throw error;
    throw createError({
      statusCode: 500,
      statusMessage: `Failed to reject version: ${err.message || String(error)}`
    });
  }
});

export { rejectVersion_post as default };
//# sourceMappingURL=reject-version.post.mjs.map
