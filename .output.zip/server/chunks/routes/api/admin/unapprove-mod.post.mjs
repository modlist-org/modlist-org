import { n as defineEventHandler, l as createError, N as readBody } from '../../../_/nitro.mjs';
import { M as Mod } from '../../../_/Mod.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'mongoose';
import 'node:url';
import 'node:crypto';

const unapproveMod_post = defineEventHandler(async (event) => {
  const currentUser = event.context.user;
  if (!currentUser || !currentUser.isAdmin) {
    throw createError({
      statusCode: 403,
      statusMessage: "Access denied. Administrator privileges required."
    });
  }
  const body = await readBody(event);
  const { modId } = body;
  if (!modId) {
    throw createError({
      statusCode: 400,
      statusMessage: "Missing modId parameter."
    });
  }
  try {
    const mod = await Mod.findById(modId);
    if (!mod) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mod not found."
      });
    }
    mod.isApproved = false;
    mod.updatedAt = /* @__PURE__ */ new Date();
    await mod.save();
    return {
      success: true,
      message: "Mod unapproved successfully."
    };
  } catch (error) {
    console.error("Unapprove mod error:", error);
    const err = error;
    if (err.statusCode) throw error;
    throw createError({
      statusCode: 500,
      statusMessage: `Failed to unapprove mod: ${err.message || String(error)}`
    });
  }
});

export { unapproveMod_post as default };
//# sourceMappingURL=unapprove-mod.post.mjs.map
