import { n as defineEventHandler, l as createError, N as readBody } from '../../../_/nitro.mjs';
import { M as Mod } from '../../../_/Mod.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'mongoose';
import 'node:url';
import 'node:crypto';

const rejectEdit_post = defineEventHandler(async (event) => {
  const currentUser = event.context.user;
  if (!currentUser || !currentUser.isAdmin) {
    throw createError({
      statusCode: 403,
      statusMessage: "Access denied. Administrator privileges required."
    });
  }
  const body = await readBody(event);
  const { modId, reason } = body;
  if (!modId) {
    throw createError({
      statusCode: 400,
      statusMessage: "Missing modId parameter."
    });
  }
  const rejectionReason = reason || "No reason provided.";
  try {
    const mod = await Mod.findById(modId);
    if (!mod) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mod not found."
      });
    }
    mod.editRejectionReason = rejectionReason;
    mod.pendingEdit = null;
    mod.updatedAt = /* @__PURE__ */ new Date();
    await mod.save();
    return {
      success: true,
      message: "Mod edits rejected successfully."
    };
  } catch (error) {
    console.error("Reject mod edits error:", error);
    const err = error;
    if (err.statusCode) throw error;
    throw createError({
      statusCode: 500,
      statusMessage: `Failed to reject mod edits: ${err.message || String(error)}`
    });
  }
});

export { rejectEdit_post as default };
//# sourceMappingURL=reject-edit.post.mjs.map
