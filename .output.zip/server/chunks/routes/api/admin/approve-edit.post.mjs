import { n as defineEventHandler, l as createError, N as readBody } from '../../../_/nitro.mjs';
import { M as Mod } from '../../../_/Mod.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'mongoose';
import 'node:url';
import 'node:crypto';

const approveEdit_post = defineEventHandler(async (event) => {
  const currentUser = event.context.user;
  if (!currentUser || !currentUser.isAdmin) {
    throw createError({
      statusCode: 403,
      statusMessage: "Access denied. Administrator privileges required."
    });
  }
  const body = await readBody(event);
  const { modId } = body;
  if (!modId) {
    throw createError({
      statusCode: 400,
      statusMessage: "Missing modId parameter."
    });
  }
  try {
    const mod = await Mod.findById(modId);
    if (!mod) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mod not found."
      });
    }
    if (!mod.pendingEdit) {
      throw createError({
        statusCode: 400,
        statusMessage: "Mod does not have a pending edit to approve."
      });
    }
    const edit = mod.pendingEdit;
    if (edit.name) mod.name = edit.name;
    if (edit.summary) mod.summary = edit.summary;
    if (edit.description !== void 0) mod.description = edit.description;
    if (edit.game) mod.game = edit.game;
    if (edit.logo !== void 0) mod.logo = edit.logo;
    if (edit.sourceUrl !== void 0) mod.sourceUrl = edit.sourceUrl;
    if (edit.categories && edit.categories.length > 0) {
      mod.categories = edit.categories;
    }
    mod.pendingEdit = null;
    mod.editRejectionReason = "";
    mod.updatedAt = /* @__PURE__ */ new Date();
    await mod.save();
    return {
      success: true,
      message: "Mod edits approved and applied successfully."
    };
  } catch (error) {
    console.error("Approve mod edits error:", error);
    const err = error;
    if (err.statusCode) throw error;
    throw createError({
      statusCode: 500,
      statusMessage: `Failed to approve mod edits: ${err.message || String(error)}`
    });
  }
});

export { approveEdit_post as default };
//# sourceMappingURL=approve-edit.post.mjs.map
