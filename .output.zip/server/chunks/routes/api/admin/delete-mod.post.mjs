import { n as defineEventHandler, l as createError, N as readBody } from '../../../_/nitro.mjs';
import { M as Mod } from '../../../_/Mod.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'mongoose';
import 'node:url';
import 'node:crypto';

const deleteMod_post = defineEventHandler(async (event) => {
  const currentUser = event.context.user;
  if (!currentUser || !currentUser.isAdmin) {
    throw createError({
      statusCode: 403,
      statusMessage: "Access denied. Administrator privileges required."
    });
  }
  const body = await readBody(event);
  const { modId } = body;
  if (!modId) {
    throw createError({
      statusCode: 400,
      statusMessage: "Missing modId parameter."
    });
  }
  try {
    const mod = await Mod.findById(modId);
    if (!mod) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mod not found."
      });
    }
    await Mod.findByIdAndDelete(modId);
    return {
      success: true,
      message: "Mod deleted successfully."
    };
  } catch (error) {
    console.error("Delete mod error:", error);
    const err = error;
    if (err.statusCode) throw error;
    throw createError({
      statusCode: 500,
      statusMessage: `Failed to delete mod: ${err.message || String(error)}`
    });
  }
});

export { deleteMod_post as default };
//# sourceMappingURL=delete-mod.post.mjs.map
