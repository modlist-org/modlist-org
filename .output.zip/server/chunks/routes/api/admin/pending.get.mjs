import { n as defineEventHandler, l as createError } from '../../../_/nitro.mjs';
import { M as Mod } from '../../../_/Mod.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'mongoose';
import 'node:url';
import 'node:crypto';

const pending_get = defineEventHandler(async (event) => {
  const currentUser = event.context.user;
  if (!currentUser || !currentUser.isAdmin) {
    throw createError({
      statusCode: 403,
      statusMessage: "Access denied. Administrator privileges required."
    });
  }
  try {
    const pendingMods = await Mod.find({
      isApproved: false,
      $or: [
        { rejectionReason: "" },
        { rejectionReason: { $exists: false } },
        { rejectionReason: null }
      ]
    }).populate("authorId", "username globalName avatar isVerifiedDeveloper").sort({ createdAt: -1 });
    const modsWithPendingVersions = await Mod.find({
      isApproved: true,
      "versions.isApproved": false
    }).populate("authorId", "username globalName avatar").populate("versions.submittedBy", "username globalName avatar isVerifiedDeveloper");
    const pendingVersions = [];
    for (const mod of modsWithPendingVersions) {
      for (const ver of mod.versions) {
        if (!ver.isApproved && !ver.rejectionReason) {
          pendingVersions.push({
            modId: mod._id,
            modName: mod.name,
            modSlug: mod.slug,
            game: mod.game,
            versionId: ver._id,
            version: ver.version,
            downloadUrl: ver.downloadUrl,
            changelog: ver.changelog,
            submittedBy: ver.submittedBy,
            createdAt: ver.createdAt
          });
        }
      }
    }
    pendingVersions.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    const pendingEdits = await Mod.find({
      pendingEdit: { $ne: null }
    }).populate("authorId", "username globalName avatar isVerifiedDeveloper").sort({ updatedAt: -1 });
    return {
      pendingMods,
      pendingVersions,
      pendingEdits
    };
  } catch (error) {
    console.error("Fetch pending submissions error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Failed to retrieve pending submissions"
    });
  }
});

export { pending_get as default };
//# sourceMappingURL=pending.get.mjs.map
