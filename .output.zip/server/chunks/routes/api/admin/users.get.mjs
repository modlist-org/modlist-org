import { n as defineEventHandler, l as createError, w as getQuery, U as User } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'mongoose';
import 'node:url';
import 'node:crypto';

const users_get = defineEventHandler(async (event) => {
  const currentUser = event.context.user;
  if (!currentUser || !currentUser.isAdmin) {
    throw createError({
      statusCode: 403,
      statusMessage: "Access denied. Administrator privileges required."
    });
  }
  const query = getQuery(event);
  const search = query.search;
  const filter = {};
  if (search && search.trim().length > 0) {
    const searchRegex = { $regex: search, $options: "i" };
    filter.$or = [
      { username: searchRegex },
      { globalName: searchRegex },
      { discordId: searchRegex }
    ];
  }
  try {
    const users = await User.find(filter).sort({ username: 1 }).limit(100);
    return { users };
  } catch (error) {
    console.error("Fetch users error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Failed to retrieve users list."
    });
  }
});

export { users_get as default };
//# sourceMappingURL=users.get.mjs.map
