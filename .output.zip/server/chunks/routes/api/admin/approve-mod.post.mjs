import { n as defineEventHandler, l as createError, N as readBody, P as sendDiscordWebhook } from '../../../_/nitro.mjs';
import { M as Mod } from '../../../_/Mod.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'mongoose';
import 'node:url';
import 'node:crypto';

const approveMod_post = defineEventHandler(async (event) => {
  const currentUser = event.context.user;
  if (!currentUser || !currentUser.isAdmin) {
    throw createError({
      statusCode: 403,
      statusMessage: "Access denied. Administrator privileges required."
    });
  }
  const body = await readBody(event);
  const { modId } = body;
  if (!modId) {
    throw createError({
      statusCode: 400,
      statusMessage: "Missing modId parameter."
    });
  }
  try {
    const mod = await Mod.findById(modId);
    if (!mod) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mod not found."
      });
    }
    const wasApproved = mod.isApproved;
    mod.isApproved = true;
    mod.rejectionReason = "";
    for (const ver of mod.versions) {
      ver.isApproved = true;
      ver.rejectionReason = "";
    }
    mod.updatedAt = /* @__PURE__ */ new Date();
    await mod.save();
    if (!wasApproved) {
      const populatedMod = await Mod.findById(mod._id).populate("authorId");
      if (populatedMod) {
        sendDiscordWebhook(populatedMod).catch((err) => {
          console.error("Failed to send Discord webhook on approval:", err);
        });
      }
    }
    return {
      success: true,
      message: "Mod approved successfully."
    };
  } catch (error) {
    console.error("Approve mod error:", error);
    const err = error;
    if (err.statusCode) throw error;
    throw createError({
      statusCode: 500,
      statusMessage: `Failed to approve mod: ${err.message || String(error)}`
    });
  }
});

export { approveMod_post as default };
//# sourceMappingURL=approve-mod.post.mjs.map
