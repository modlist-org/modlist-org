import { n as defineEventHandler, l as createError } from '../../../_/nitro.mjs';
import mongoose from 'mongoose';
import { M as Mod } from '../../../_/Mod.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'node:crypto';

const invitations_get = defineEventHandler(async (event) => {
  const currentUser = event.context.user;
  if (!currentUser) {
    throw createError({
      statusCode: 401,
      statusMessage: "You must be logged in to view collaborator invitations."
    });
  }
  try {
    const mods = await Mod.find({
      pendingCollaboratorIds: new mongoose.Types.ObjectId(currentUser.id)
    }).populate("authorId", "username globalName avatar").sort({ updatedAt: -1 });
    return { mods };
  } catch (error) {
    console.error("Fetch invitations error:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Failed to retrieve collaborator invitations"
    });
  }
});

export { invitations_get as default };
//# sourceMappingURL=invitations.get.mjs.map
