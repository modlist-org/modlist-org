import { n as defineEventHandler, C as getRouterParam, l as createError } from '../../../_/nitro.mjs';
import { M as Mod } from '../../../_/Mod.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'mongoose';
import 'node:url';
import 'node:crypto';

const index_get = defineEventHandler(async (event) => {
  var _a;
  const slug = (_a = getRouterParam(event, "slug")) == null ? void 0 : _a.toLowerCase();
  const currentUser = event.context.user;
  if (!slug) {
    throw createError({
      statusCode: 400,
      statusMessage: "Missing slug parameter."
    });
  }
  try {
    const mod = await Mod.findOne({ slug }).populate("authorId", "username globalName avatar isVerifiedDeveloper").populate("collaboratorIds", "username globalName avatar isVerifiedDeveloper").populate("pendingCollaboratorIds", "username globalName avatar isVerifiedDeveloper").populate("versions.submittedBy", "username globalName avatar isVerifiedDeveloper");
    if (!mod) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mod not found."
      });
    }
    const modObj = mod.toObject();
    const isOwnerOrAdmin = currentUser && (currentUser.isAdmin || modObj.authorId._id.toString() === currentUser.id || modObj.collaboratorIds.some((c) => c._id.toString() === currentUser.id));
    if (!mod.isApproved && !isOwnerOrAdmin) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mod not found."
      });
    }
    if (!isOwnerOrAdmin) {
      modObj.versions = modObj.versions.filter((v) => v.isApproved);
    }
    modObj.versions.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    const latestVersion = modObj.versions[0] || null;
    if (!isOwnerOrAdmin) {
      delete modObj.pendingEdit;
    }
    return {
      mod: modObj,
      latestVersion,
      isEditable: !!isOwnerOrAdmin
    };
  } catch (error) {
    console.error("Fetch mod details error:", error);
    const err = error;
    if (err.statusCode) throw error;
    throw createError({
      statusCode: 500,
      statusMessage: "Failed to retrieve mod details"
    });
  }
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
