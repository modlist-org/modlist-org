import { n as defineEventHandler, C as getRouterParam, l as createError, N as readBody } from '../../../../_/nitro.mjs';
import mongoose from 'mongoose';
import { M as Mod } from '../../../../_/Mod.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'node:crypto';

const versions_post = defineEventHandler(async (event) => {
  var _a;
  const slug = (_a = getRouterParam(event, "slug")) == null ? void 0 : _a.toLowerCase();
  const currentUser = event.context.user;
  if (!currentUser) {
    throw createError({
      statusCode: 401,
      statusMessage: "You must be logged in to submit a mod update."
    });
  }
  if (!slug) {
    throw createError({
      statusCode: 400,
      statusMessage: "Missing slug parameter."
    });
  }
  const body = await readBody(event);
  const { version, downloadUrl, changelog } = body;
  if (!version || !downloadUrl) {
    throw createError({
      statusCode: 400,
      statusMessage: "Version string and direct download URL are required."
    });
  }
  if (!downloadUrl.startsWith("http://") && !downloadUrl.startsWith("https://")) {
    throw createError({
      statusCode: 400,
      statusMessage: "Download link must be a valid direct HTTP/HTTPS URL."
    });
  }
  try {
    const mod = await Mod.findOne({ slug });
    if (!mod) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mod not found."
      });
    }
    const isOwner = mod.authorId.toString() === currentUser.id;
    const isCollab = mod.collaboratorIds.some((id) => id.toString() === currentUser.id);
    const isAdmin = currentUser.isAdmin;
    if (!isOwner && !isCollab && !isAdmin) {
      throw createError({
        statusCode: 403,
        statusMessage: "You do not have permission to submit updates to this mod."
      });
    }
    const isAutoApproved = currentUser.isVerifiedDeveloper || currentUser.isAdmin;
    const normalizedNewVersion = version.trim().replace(/^v/i, "");
    const existingVersionIndex = mod.versions.findIndex((v) => v.version.trim().replace(/^v/i, "") === normalizedNewVersion);
    if (existingVersionIndex > -1) {
      const existingVer = mod.versions[existingVersionIndex];
      if (!existingVer) {
        throw createError({
          statusCode: 500,
          statusMessage: "Failed to access version document"
        });
      }
      if (existingVer.isApproved) {
        throw createError({
          statusCode: 400,
          statusMessage: `Version ${version} is already approved and active.`
        });
      }
      existingVer.downloadUrl = downloadUrl;
      existingVer.changelog = changelog || "";
      existingVer.isApproved = isAutoApproved;
      existingVer.rejectionReason = "";
      existingVer.createdAt = /* @__PURE__ */ new Date();
      existingVer.submittedBy = new mongoose.Types.ObjectId(currentUser.id);
      mod.updatedAt = /* @__PURE__ */ new Date();
      await mod.save();
      return {
        success: true,
        version: existingVer
      };
    }
    const newVersion = {
      version,
      downloadUrl,
      changelog: changelog || "",
      isApproved: isAutoApproved,
      submittedBy: new mongoose.Types.ObjectId(currentUser.id),
      createdAt: /* @__PURE__ */ new Date()
    };
    mod.versions.push(newVersion);
    mod.updatedAt = /* @__PURE__ */ new Date();
    await mod.save();
    return {
      success: true,
      version: newVersion
    };
  } catch (error) {
    console.error("Submit version update error:", error);
    const err = error;
    if (err.statusCode) throw error;
    throw createError({
      statusCode: 500,
      statusMessage: `Failed to submit version update: ${err.message || String(error)}`
    });
  }
});

export { versions_post as default };
//# sourceMappingURL=versions.post.mjs.map
