import { n as defineEventHandler, C as getRouterParam, l as createError, N as readBody } from '../../../../../_/nitro.mjs';
import { M as Mod } from '../../../../../_/Mod.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'mongoose';
import 'node:url';
import 'node:crypto';

const delete_post = defineEventHandler(async (event) => {
  var _a;
  const slug = (_a = getRouterParam(event, "slug")) == null ? void 0 : _a.toLowerCase();
  const currentUser = event.context.user;
  if (!currentUser) {
    throw createError({
      statusCode: 401,
      statusMessage: "You must be logged in to delete a version submission."
    });
  }
  if (!slug) {
    throw createError({
      statusCode: 400,
      statusMessage: "Missing slug parameter."
    });
  }
  const body = await readBody(event);
  const { versionId } = body;
  if (!versionId) {
    throw createError({
      statusCode: 400,
      statusMessage: "Missing versionId parameter."
    });
  }
  try {
    const mod = await Mod.findOne({ slug });
    if (!mod) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mod not found."
      });
    }
    const isOwner = mod.authorId.toString() === currentUser.id;
    const isCollab = mod.collaboratorIds.some((id) => id.toString() === currentUser.id);
    const isAdmin = currentUser.isAdmin;
    if (!isOwner && !isCollab && !isAdmin) {
      throw createError({
        statusCode: 403,
        statusMessage: "You do not have permission to manage this mod."
      });
    }
    const versions = mod.versions;
    const version = versions.id(versionId);
    if (!version) {
      throw createError({
        statusCode: 404,
        statusMessage: "Version submission not found."
      });
    }
    if (version.isApproved && !isAdmin) {
      throw createError({
        statusCode: 400,
        statusMessage: "Approved versions can only be deleted by an administrator."
      });
    }
    versions.pull(versionId);
    mod.updatedAt = /* @__PURE__ */ new Date();
    await mod.save();
    return {
      success: true,
      message: "Version submission deleted successfully."
    };
  } catch (error) {
    console.error("Delete version submission error:", error);
    const err = error;
    if (err.statusCode) throw error;
    throw createError({
      statusCode: 500,
      statusMessage: `Failed to delete version submission: ${err.message || String(error)}`
    });
  }
});

export { delete_post as default };
//# sourceMappingURL=delete.post.mjs.map
