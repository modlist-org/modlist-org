import { n as defineEventHandler, C as getRouterParam, l as createError } from '../../../../_/nitro.mjs';
import { M as Mod } from '../../../../_/Mod.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'mongoose';
import 'node:url';
import 'node:crypto';

const download_post = defineEventHandler(async (event) => {
  var _a;
  const slug = (_a = getRouterParam(event, "slug")) == null ? void 0 : _a.toLowerCase();
  if (!slug) {
    throw createError({
      statusCode: 400,
      statusMessage: "Missing slug parameter."
    });
  }
  try {
    const mod = await Mod.findOneAndUpdate(
      { slug, isApproved: true },
      { $inc: { downloads: 1 } },
      { new: true }
    );
    if (!mod) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mod not found or not approved."
      });
    }
    return {
      success: true,
      downloads: mod.downloads
    };
  } catch (error) {
    console.error("Increment download count error:", error);
    const err = error;
    if (err.statusCode) throw error;
    throw createError({
      statusCode: 500,
      statusMessage: "Failed to record download."
    });
  }
});

export { download_post as default };
//# sourceMappingURL=download.post.mjs.map
