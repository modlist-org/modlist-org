import { n as defineEventHandler, C as getRouterParam, l as createError, N as readBody, U as User } from '../../../_/nitro.mjs';
import mongoose from 'mongoose';
import { M as Mod } from '../../../_/Mod.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'node:crypto';

const index_put = defineEventHandler(async (event) => {
  var _a;
  const slug = (_a = getRouterParam(event, "slug")) == null ? void 0 : _a.toLowerCase();
  const currentUser = event.context.user;
  if (!currentUser) {
    throw createError({
      statusCode: 401,
      statusMessage: "You must be logged in to edit a mod."
    });
  }
  if (!slug) {
    throw createError({
      statusCode: 400,
      statusMessage: "Missing slug parameter."
    });
  }
  const body = await readBody(event);
  const { name, summary, description, game, categories, collaboratorIds, logo, sourceUrl } = body;
  if (logo && typeof logo === "string" && logo.length > 15e5) {
    throw createError({
      statusCode: 400,
      statusMessage: "Logo size must be smaller than 1MB."
    });
  }
  if (sourceUrl && typeof sourceUrl === "string") {
    if (!sourceUrl.startsWith("http://") && !sourceUrl.startsWith("https://")) {
      throw createError({
        statusCode: 400,
        statusMessage: "Source code link must be a valid HTTP/HTTPS URL."
      });
    }
  }
  try {
    const mod = await Mod.findOne({ slug });
    if (!mod) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mod not found."
      });
    }
    const isOwner = mod.authorId.toString() === currentUser.id;
    const isCollab = mod.collaboratorIds.some((id) => id.toString() === currentUser.id);
    const isAdmin = currentUser.isAdmin;
    if (!isOwner && !isCollab && !isAdmin) {
      throw createError({
        statusCode: 403,
        statusMessage: "You do not have permission to edit this mod."
      });
    }
    if (isAdmin || !mod.isApproved) {
      if (name) mod.name = name;
      if (summary) mod.summary = summary;
      if (description !== void 0) mod.description = description;
      if (game && ["adofai", "rhythm-doctor"].includes(game)) mod.game = game;
      if (logo !== void 0) mod.logo = logo;
      if (sourceUrl !== void 0) mod.sourceUrl = sourceUrl;
      if (categories !== void 0) {
        if (!Array.isArray(categories) || categories.length === 0 || categories.some((cat) => !["ui", "gameplay", "utility", "visuals", "library"].includes(cat))) {
          throw createError({
            statusCode: 400,
            statusMessage: "Invalid or empty categories selected."
          });
        }
        mod.categories = categories;
      }
      if (!mod.isApproved) {
        mod.rejectionReason = "";
      }
      mod.pendingEdit = null;
    } else {
      let isChanged = false;
      const proposedEdit = {};
      if (name && name !== mod.name) {
        proposedEdit.name = name;
        isChanged = true;
      }
      if (summary && summary !== mod.summary) {
        proposedEdit.summary = summary;
        isChanged = true;
      }
      if (description !== void 0 && description !== mod.description) {
        proposedEdit.description = description;
        isChanged = true;
      }
      if (game && game !== mod.game && ["adofai", "rhythm-doctor"].includes(game)) {
        proposedEdit.game = game;
        isChanged = true;
      }
      if (logo !== void 0 && logo !== mod.logo) {
        proposedEdit.logo = logo;
        isChanged = true;
      }
      if (sourceUrl !== void 0 && sourceUrl !== mod.sourceUrl) {
        proposedEdit.sourceUrl = sourceUrl;
        isChanged = true;
      }
      if (categories !== void 0) {
        if (!Array.isArray(categories) || categories.length === 0 || categories.some((cat) => !["ui", "gameplay", "utility", "visuals", "library"].includes(cat))) {
          throw createError({
            statusCode: 400,
            statusMessage: "Invalid or empty categories selected."
          });
        }
        const categoriesChanged = categories.length !== mod.categories.length || categories.some((cat) => !mod.categories.includes(cat));
        if (categoriesChanged) {
          proposedEdit.categories = categories;
          isChanged = true;
        }
      }
      if (isChanged) {
        const prevPending = mod.pendingEdit ? {
          name: mod.pendingEdit.name,
          summary: mod.pendingEdit.summary,
          description: mod.pendingEdit.description,
          game: mod.pendingEdit.game,
          logo: mod.pendingEdit.logo,
          sourceUrl: mod.pendingEdit.sourceUrl,
          categories: mod.pendingEdit.categories ? [...mod.pendingEdit.categories] : void 0
        } : {};
        mod.pendingEdit = {
          ...prevPending,
          ...proposedEdit,
          createdAt: /* @__PURE__ */ new Date()
        };
        mod.editRejectionReason = "";
      }
    }
    if (collaboratorIds !== void 0 && (isOwner || isAdmin)) {
      const newPendingCollabIds = [];
      const newAcceptedCollabIds = [];
      if (Array.isArray(collaboratorIds)) {
        for (const collabId of collaboratorIds) {
          if (collabId === mod.authorId.toString()) continue;
          const collabUser = await User.findById(collabId);
          if (collabUser) {
            const objectId = new mongoose.Types.ObjectId(collabUser._id);
            if (mod.collaboratorIds && mod.collaboratorIds.some((id) => id.toString() === collabId)) {
              newAcceptedCollabIds.push(objectId);
            } else if (mod.pendingCollaboratorIds && mod.pendingCollaboratorIds.some((id) => id.toString() === collabId)) {
              newPendingCollabIds.push(objectId);
            } else {
              newPendingCollabIds.push(objectId);
            }
          }
        }
      }
      mod.collaboratorIds = newAcceptedCollabIds;
      mod.pendingCollaboratorIds = newPendingCollabIds;
    }
    mod.updatedAt = /* @__PURE__ */ new Date();
    await mod.save();
    return {
      success: true,
      mod: {
        name: mod.name,
        slug: mod.slug,
        summary: mod.summary,
        game: mod.game,
        categories: mod.categories,
        collaboratorIds: mod.collaboratorIds
      }
    };
  } catch (error) {
    console.error("Update mod error:", error);
    const err = error;
    if (err.statusCode) throw error;
    throw createError({
      statusCode: 500,
      statusMessage: `Failed to update mod: ${err.message || String(error)}`
    });
  }
});

export { index_put as default };
//# sourceMappingURL=index.put.mjs.map
