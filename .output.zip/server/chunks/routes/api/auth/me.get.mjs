import { n as defineEventHandler } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'mongoose';
import 'node:url';
import 'node:crypto';

const me_get = defineEventHandler((event) => {
  return {
    user: event.context.user || null
  };
});

export { me_get as default };
//# sourceMappingURL=me.get.mjs.map
