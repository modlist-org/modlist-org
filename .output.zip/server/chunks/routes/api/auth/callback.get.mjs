import { n as defineEventHandler, w as getQuery, l as createError, Y as useRuntimeConfig, U as User, T as signJwt, R as setCookie, Q as sendRedirect } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'mongoose';
import 'node:url';
import 'node:crypto';

const callback_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const code = query.code;
  if (!code) {
    throw createError({
      statusCode: 400,
      statusMessage: "Missing authorization code from Discord callback"
    });
  }
  const config = useRuntimeConfig(event);
  const clientId = config.discordClientId;
  const clientSecret = config.discordClientSecret;
  const redirectUri = config.discordRedirectUri;
  const jwtSecret = config.jwtSecret;
  try {
    const tokenResponse = await $fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        grant_type: "authorization_code",
        code,
        redirect_uri: redirectUri
      }).toString()
    });
    const accessToken = tokenResponse.access_token;
    const discordUser = await $fetch("https://discord.com/api/users/@me", {
      headers: {
        Authorization: `Bearer ${accessToken}`
      }
    });
    const avatarUrl = discordUser.avatar ? `https://cdn.discordapp.com/avatars/${discordUser.id}/${discordUser.avatar}.png` : `https://cdn.discordapp.com/embed/avatars/${parseInt(discordUser.discriminator || "0") % 5}.png`;
    let isAdmin = false;
    if (config.adminDiscordIds) {
      const adminIds = config.adminDiscordIds.split(",").map((id) => id.trim());
      if (adminIds.includes(discordUser.id)) {
        isAdmin = true;
      }
    }
    const userCount = await User.countDocuments();
    if (userCount === 0) {
      isAdmin = true;
    }
    let user = await User.findOne({ discordId: discordUser.id });
    if (!user) {
      user = new User({
        discordId: discordUser.id,
        username: discordUser.username,
        globalName: discordUser.global_name || discordUser.username,
        avatar: avatarUrl,
        isAdmin,
        isVerifiedDeveloper: isAdmin,
        // admins are auto-verified developers too
        lastSyncedAt: /* @__PURE__ */ new Date()
      });
      await user.save();
    } else {
      user.username = discordUser.username;
      user.globalName = discordUser.global_name || discordUser.username;
      user.avatar = avatarUrl;
      user.lastSyncedAt = /* @__PURE__ */ new Date();
      if (isAdmin) {
        user.isAdmin = true;
        user.isVerifiedDeveloper = true;
      }
      await user.save();
    }
    const tokenPayload = {
      id: user._id.toString(),
      discordId: user.discordId,
      username: user.username,
      accessToken
    };
    const token = signJwt(tokenPayload, jwtSecret);
    setCookie(event, "token", token, {
      httpOnly: true,
      secure: true,
      sameSite: "lax",
      path: "/",
      maxAge: 7 * 24 * 3600
      // 7 days
    });
    return sendRedirect(event, "/");
  } catch (error) {
    console.error("Discord login callback error:", error);
    const err = error;
    throw createError({
      statusCode: 500,
      statusMessage: `Authentication failed: ${err.message || String(error)}`
    });
  }
});

export { callback_get as default };
//# sourceMappingURL=callback.get.mjs.map
