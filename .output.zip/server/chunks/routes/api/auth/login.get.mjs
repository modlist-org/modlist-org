import { n as defineEventHandler, Y as useRuntimeConfig, l as createError, Q as sendRedirect } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue-router';
import 'node:fs';
import 'node:path';
import 'mongoose';
import 'node:url';
import 'node:crypto';

const login_get = defineEventHandler(async (event) => {
  const config = useRuntimeConfig(event);
  const clientId = config.discordClientId;
  const redirectUri = config.discordRedirectUri;
  if (!clientId || !redirectUri) {
    throw createError({
      statusCode: 500,
      statusMessage: "Discord OAuth credentials are not configured in runtimeConfig."
    });
  }
  const oauthUrl = `https://discord.com/api/oauth2/authorize?client_id=${clientId}&redirect_uri=${encodeURIComponent(
    redirectUri
  )}&response_type=code&scope=identify`;
  return sendRedirect(event, oauthUrl);
});

export { login_get as default };
//# sourceMappingURL=login.get.mjs.map
